package com.example.hris_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
