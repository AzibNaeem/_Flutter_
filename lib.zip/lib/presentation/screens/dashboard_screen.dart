import 'package:flutter/material.dart';
import '../routes.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final userName = "Eveline Murphy";
    return Scaffold(
      backgroundColor: const Color(0xFFF9F9FB),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.black87,
        title: Row(
          children: [
            const CircleAvatar(
              radius: 20,
              backgroundImage: NetworkImage('https://i.pravatar.cc/150?img=1'),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Welcome back!", style: TextStyle(fontSize: 12)),
                Text(userName, style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            )
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 8),
          _buildGridCards(context),
          const SizedBox(height: 24),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Today Schedule",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ),
          ),
          const SizedBox(height: 12),
          _buildScheduleTimeline(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: Colors.deepPurple,
        unselectedItemColor: Colors.grey,
        currentIndex: 0,
        onTap: (index) {},
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: ''),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today), label: ''),
          BottomNavigationBarItem(icon: Icon(Icons.message), label: ''),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: ''),
        ],
      ),
    );
  }

  Widget _buildGridCards(BuildContext context) {
    final cards = [
      _DashboardCardData(
        title: 'Leave & Attendance',
        value: '2.600',
        icon: Icons.calendar_today,
        color: const Color(0xFFECECFF),
        route: '/attendance',
      ),
      _DashboardCardData(
        title: 'Employee Report',
        value: '2.600',
        icon: Icons.bar_chart,
        color: const Color(0xFF2C2C2E),
        textColor: Colors.white,
        route: '/report',
      ),
      _DashboardCardData(
        title: 'Salary Management',
        value: '2.600',
        icon: Icons.attach_money,
        color: const Color(0xFF0062FF),
        route: '/payslip',
        badge: '+12%',
      ),
      _DashboardCardData(
        title: 'Onboarding & Training',
        value: '2.600',
        icon: Icons.school,
        color: const Color(0xFFEEF6FF),
        route: '/onboarding',
        badge: '+12%',
      ),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: cards.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.2,
        ),
        itemBuilder: (context, index) => _FuturisticCard(card: cards[index]),
      ),
    );
  }

  Widget _buildScheduleTimeline() {
    return SizedBox(
      height: 80,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        children: const [
          _ScheduleBlock(time: '08:00'),
          _ScheduleBlock(time: '09:00'),
          _ScheduleBlock(time: '09:35', active: true),
          _ScheduleBlock(time: '10:00'),
        ],
      ),
    );
  }
}

class _ScheduleBlock extends StatelessWidget {
  final String time;
  final bool active;

  const _ScheduleBlock({required this.time, this.active = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 70,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        color: active ? Colors.deepPurple : Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300),
      ),
      alignment: Alignment.center,
      child: Text(
        time,
        style: TextStyle(
          color: active ? Colors.white : Colors.black87,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

class _DashboardCardData {
  final String title;
  final String value;
  final IconData icon;
  final Color color;
  final Color textColor;
  final String route;
  final String? badge;

  _DashboardCardData({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
    this.textColor = Colors.black87,
    required this.route,
    this.badge,
  });
}

class _FuturisticCard extends StatelessWidget {
  final _DashboardCardData card;

  const _FuturisticCard({required this.card});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (card.route.isNotEmpty) {
          Navigator.pushNamed(context, card.route);
        }
      },
      child: Container(
        decoration: BoxDecoration(
          color: card.color,
          borderRadius: BorderRadius.circular(16),
        ),
        padding: const EdgeInsets.all(16),
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(card.icon, size: 26, color: card.textColor),
                const Spacer(),
                Text(card.title,
                    style: TextStyle(fontSize: 13, color: card.textColor)),
                const SizedBox(height: 6),
                Text(
                  card.value,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: card.textColor,
                  ),
                ),
              ],
            ),
            if (card.badge != null)
              Positioned(
                top: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    card.badge!,
                    style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
