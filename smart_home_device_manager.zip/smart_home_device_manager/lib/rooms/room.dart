import '../models/smart_device.dart';

class Room {
  String roomName;
  List<SmartDevice> devices = [];

  Room(this.roomName);

  void addDevice(SmartDevice device) {
    devices.add(device);
    print('Device "${device.name}" added to $roomName.');
  }

  void removeDevice(SmartDevice device) {
    devices.remove(device);
    print('Device "${device.name}" removed from $roomName.');
  }
     void turnOnAllDevices() {
    for (var device in devices) {
      if (!device.isOn) device.turnOn();
    }
  }
      void turnOffAllDevices() {
    for (var device in devices) {
      if (device.isOn) device.turnOff();
    }
  }

  void showRoomStatus() {
    print('\n📍 Devices in $roomName:');
    for (var device in devices) {
      device.showStatus();
    }
  }
}
