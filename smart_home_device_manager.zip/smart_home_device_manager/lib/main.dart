import 'controllers/smart_home_controller.dart';
import 'factory/device_factory.dart';
import 'rooms/room.dart';
import 'models/smart_device.dart';
import 'interfaces/schedulable.dart';

void main() {
 
  SmartHomeController controller = SmartHomeController();

  Room livingRoom = Room('Living Room');
  Room bedroom = Room('Bedroom');
  controller.addRoom(livingRoom);
  controller.addRoom(bedroom);
  var garage = Room('Garage');
  controller.addRoom(garage);

  SmartDevice light1 = DeviceFactory.create(
    'light',
    'Ceiling Light',
    'Living Room',
  );
  SmartDevice thermostat1 = DeviceFactory.create(
    'thermostat',
    'Room Thermostat',
    'Bedroom'
  );
  SmartDevice camera1 = DeviceFactory.create(
    'camera',
    'Main Door Camera',
    'Living Room',
  );
  var garageLight = DeviceFactory.create('light', 'Garage Light', 'Garage');
  var garageCamera = DeviceFactory.create(
    'camera',
    'Garage Camera',
    'Garage',
  );
  controller.addDeviceToRoom('Garage', garageLight);
  controller.addDeviceToRoom('Garage', garageCamera);
 
  controller.addDeviceToRoom('Living Room', light1);
  controller.addDeviceToRoom('Living Room', camera1);
  controller.addDeviceToRoom('Bedroom', thermostat1);

 
  controller.turnOnDevicesInRoom('Living Room');

 
  if (light1 is Schedulable) {
    (light1 as Schedulable).scheduleOn('7:00 PM');
    (light1 as Schedulable).scheduleOff('11:00 PM');
  }

  if (thermostat1 is Schedulable) {
    (thermostat1 as Schedulable).scheduleOn('6:00 AM');
    (thermostat1 as Schedulable).scheduleOff('10:00 AM');
  }


  controller.showAllStatus();


  controller.turnOffDevicesInRoom('Bedroom');
  controller.showAllStatus();
}
