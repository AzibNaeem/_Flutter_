import '../rooms/room.dart';
import '../models/smart_device.dart';

class SmartHomeController {
  List<Room> rooms = [];

  void addRoom(Room room) {
    rooms.add(room);
    print('Room "${room.roomName}" added to Smart Home.');
  }

  void removeRoom(Room room) {
    rooms.remove(room);
    print('Room "${room.roomName}" removed from Smart Home.');
  }

  void addDeviceToRoom(String roomName, SmartDevice device) {
    final room = _getRoomByName(roomName);
    if (room != null) {
      room.addDevice(device);
    } else {
      print('❌ Room "$roomName" not found!');
    }
  }

  void turnOnDevicesInRoom(String roomName) {
    final room = _getRoomByName(roomName);
    if (room != null) {
      room.turnOnAllDevices();
    } else {
      print('❌ Room "$roomName" not found!');
    }
  }

  void turnOffDevicesInRoom(String roomName) {
    final room = _getRoomByName(roomName);
    if (room != null) {
      room.turnOffAllDevices();
    } else {
      print('❌ Room "$roomName" not found!');
    }
  }

  void showAllStatus() {
    print('\n my Smart Home Device Summary:');
    for (var room in rooms) {
      room.showRoomStatus();
    }
  }

  Room? _getRoomByName(String name) {
    try {
      return rooms.firstWhere(
        (r) => r.roomName.toLowerCase() == name.toLowerCase(),
      );
    } catch (e) {
      return null;
    }
  }
}
