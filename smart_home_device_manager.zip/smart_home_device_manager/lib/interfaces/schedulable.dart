abstract class Schedulable {
  void scheduleOn(String time);
  void scheduleOff(String time);
}
