import 'smart_device.dart';
import '../interfaces/schedulable.dart';

class Light extends SmartDevice implements Schedulable {
  Light(String name, String location) : super(name, location);

  @override
  void scheduleOn(String time) {
    print('Light "$name" in $location is scheduled to turn ON at $time.');
  }

  @override
  void scheduleOff(String time) {
    print('Light "$name" in $location is scheduled to turn OFF at $time.');
  }

  @override
  void turnOn() {
    super.turnOn();
    print('Light "$name" is now glowing.');
  }

  @override
  void turnOff() {
    super.turnOff();
    print('Light "$name" is now dark.');
  }
}
