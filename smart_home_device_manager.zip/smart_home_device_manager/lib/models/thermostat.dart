import 'smart_device.dart';
import '../interfaces/schedulable.dart';

class Thermostat extends SmartDevice implements Schedulable {
  double temperature;

  Thermostat(String name, String location, {this.temperature = 24.0})
      : super(name, location);

  void setTemperature(double temp) {
    temperature = temp;
    print('Thermostat "$name" in $location set to $temperature°C.');
  }

  @override
  void scheduleOn(String time) {
    print('Thermostat "$name" in $location is scheduled to turn ON at $time.');
  }

  @override
  void scheduleOff(String time) {
    print('Thermostat "$name" in $location is scheduled to turn OFF at $time.');
  }

  @override
  void turnOn() {
    super.turnOn();
    print('Thermostat "$name" is now heating/cooling to $temperature°C.');
  }

  @override
  void turnOff() {
    super.turnOff();
    print('Thermostat "$name" is turned off and idle.');
  }
}
