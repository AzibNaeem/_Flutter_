abstract class SmartDevice {
  String name;
  String location;
  bool isOn;

  SmartDevice(this.name, this.location) : isOn = false;

  void turnOn() {
    isOn = true;
    print('$name in $location is turned ON.');
  }

  void turnOff() {
    isOn = false;
    print('$name in $location is turned OFF.');
  }

  void showStatus() {
    String status = isOn ? 'ON' : 'OFF';
    print('$name in $location is currently $status.');
  }
}
