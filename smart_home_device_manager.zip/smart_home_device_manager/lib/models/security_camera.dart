import 'smart_device.dart';

class SecurityCamera extends SmartDevice {
  bool isRecording = false;

  SecurityCamera(String name, String location) : super(name, location);

  void startRecording() {
    if (!isRecording) {
      isRecording = true;
      print('Security camera "$name" in $location started recording.');
    } else {
      print('Security camera "$name" is already recording.');
    }
  }

  void stopRecording() {
    if (isRecording) {
      isRecording = false;
      print('Security camera "$name" in $location stopped recording.');
    } else {
      print('Security camera "$name" is not recording.');
    }
  }

  @override
  void turnOn() {
    super.turnOn();
    startRecording();
  }

  @override
  void turnOff() {
    super.turnOff();
    stopRecording();
  }
}
