import '../models/light.dart';
import '../models/thermostat.dart';
import '../models/security_camera.dart';
import '../models/smart_device.dart';

class DeviceFactory {
  static SmartDevice create(String type, String name, String location) {
    switch (type.toLowerCase()) {
      case 'light':
        return Light(name, location);
      case 'thermostat':
        return Thermostat(name, location);
      case 'camera':
      case 'securitycamera':
        return SecurityCamera(name, location);
      default:
        throw Exception('Unknown device type: $type');
    }
  }
}
